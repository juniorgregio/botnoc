<?php

// Mostra todas as informa��es, usa o padr�o INFO_ALL
phpinfo();

// Mostra apenas informa��es dos m�dulos.
// phpinfo(8) mostra um resultado identico.
phpinfo(INFO_MODULES);

?>